<template>
  <div>  
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <h1>Bài 1</h1>
  <body> 
    <div class="row">
      <div class="col-lg-4"></div>
      <div class="col-lg-4">
        <div class="card">
          <div class="card-header">
            THÔNG TIN SINH VIÊN
          </div>
          <div class="card-body">
            <div class="form-group">
              <label for="">Họ và tên</label>
              <input type="text" name="" id="tensp" class="form-control" placeholder="" aria-describedby="helpId" >
              <small id="helpId" ></small>
              <label for="">Điểm</label>
              <input type="number" name="" id="diem" class="form-control" placeholder="" aria-describedby="helpId">
              <small id="helpId" ></small>
              <label for="">Email</label>
              <input type="text" name="" id="email" class="form-control" placeholder="" aria-describedby="helpId">
              <small id="helpId" ></small>
              <label for="">Số xe</label>
              <input type="text" name="" id="soxe" class="form-control" placeholder="" aria-describedby="helpId">
              <small id="helpId" ></small>
            </div>
          </div>
          <div class="card-footer text-muted">
            <button type="button" class="btn btn-primary" @click="kiemtra()">Lưu</button>
          </div>
        </div>
      </div>
      <div class="col-lg-4"></div>
    </div>
  </body>
 <h1>Bài 2,3</h1>
    <div class="card">
      <div class="card-header">DANH SÁCH HÀNG HÓA</div>
      <div class="card-body">
        <table border="1">
          <thead>
            <tr>
              <th @click="sortBy('name')">
                SẢN PHẨM
              </th>
              <th @click="sortBy('dongia')">
                ĐƠN GIÁ
              </th>
              <th @click="sortBy('giamgia')">
                GIẢM GIÁ
              </th>
              <th @click="sortBy('ngay')">
                NGÀY
              </th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(item, index) in paginatedSanPham" :key="index">
              <td>{{ capitalizeProductName(item) }}</td>
              <td>{{ formatCurrency(item.dongia) }}</td>
              <td>{{ item.giamgia / 100 }}</td>
              <td>{{ formatDate(item.ngay) }}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="card-footer text-center">
        <button @click="prevPage" :disabled="currentPage === 1">👈</button>
        <button @click="nextPage" :disabled="currentPage === pageCount">👉</button>
        <button @click="sortByAscending()">👆</button>
        <button @click="sortByDescending()">👇</button><br>
        <span>{{ currentPage }} / {{ pageCount }}</span>
      </div>
    </div>
    <h1>Bài 4</h1>
<div class="container mt-3">
  <div class="row">
    <div class="col-12 col-sm-4 col-md-4 col-lg-4 mt-2 ">
      <input v-model="searching" placeholder="Tìm sản phẩm" class="input form-control mr-sm-2" />
    </div>
    <div class="col-12 col-sm-4 col-md-4 col-lg-4 mt-2 form-inline my-2 my-lg-0">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit" data-toggle="modal" data-target=".bd-example-modal-xl" @click="showCartModal">
        Giỏ hàng của bạn !
        <span v-if="itemcount === 0">Bạn chưa mua hàng</span>
        <span v-else>Bạn đã mua {{ itemcount }} hàng !</span>
      </button>

    </div>
  </div>
  <div class="row">
    <div v-for="(item,index) in filterName()" :key="index" class="col-12 col-sm-6 col-md-4 col-lg-3 mt-2 ">
      <div class="card text-center border-primary" style="height: 100%;">
        <div class="card-header bg-primary text-light ">
          {{ item.name }}
        </div>
        <div class="card-body">
          <img :src="item.image" alt="" />
        </div>
        <div class="card-footer text-danger">
          {{ formatCurrency(item.price) }}
          <br />
          <button class="btn btn-primary" @click="addCart(item), showCartModal()">Mua</button>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade bd-example-modal-xl" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <table style="width: 100%;" class="text-center table" v-if="cart.length > 0">
        <thead>
          <tr>
            <th>HÌNH</th>
            <th>SẢN PHẨM</th>
            <th>Đơn giá</th>
            <th>Số lượng</th>
            <th>Tiền</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(item, index) in cart" :key="index">
            <td><img :src="item.image" style="height: 100px; width: auto;" /></td>
            <td class="align-middle">{{ item.name }}</td>
            <td class="align-middle">{{ formatCurrency(item.price) }}</td>
            <td class="align-middle">
              <button class="btn btn-primary" @click="increment(item)">+</button>
              {{ item.incart }}
              <button class="btn btn-primary" :disabled="item.incart <= 1" @click="decrement(item)">-</button>
            </td>
            <td class="align-middle">{{ (formatCurrency(item.price) * item.incart) }}</td>
            <td class="align-middle">
              <button class="btn btn-danger" @click="Delete(index)">Remove</button>
            </td>
          </tr>
          <tr>
            <th colspan="3">Tổng tiền</th>
            <th>{{ itemcount }}</th>
            <th>{{ sumTotal }}</th>
            <th>
              <button class="btn btn-danger" @click="DeleteAll()">Xóa hết</button>
            </th>
          </tr>
        </tbody>
      </table>
      <div v-else>
        <div class="btn btn-danger">Mời bạn chọn mua !</div>
      </div>
    </div>
  </div>
</div>
  </div>
</template>
<script>
export default {
  data(){
   return {
    sanpham: [
  { name: "aniseed syrup", dongia: 190.00, giamgia: 19, ngay: '03/16/2000' },
  { name: "change", dongia: 19.00, giamgia: 0, ngay: '12/18/1982' },
  { name: "aniseed syrup", dongia: 10.00, giamgia: 0, ngay: '06/14/1973' },
  { name: "chef anton's cajun seasoning", dongia: 22.00, giamgia: 0, ngay: '03/10/1976' },
  { name: "chef anton's gumbo mix", dongia: 21.35, giamgia: 0, ngay: '12/6/1978' },
  { name: "grandma's boysenberry spread", dongia: 25.00, giamgia: 3, ngay: '09/03/1981' },
  { name: "aniseed syrup", dongia: 190.00, giamgia: 2, ngay: '03/16/2000' },
  { name: "change", dongia: 19.00, giamgia: 0, ngay: '12/18/1982' },
  { name: "aniseed syrup", dongia: 10.00, giamgia: 1, ngay: '06/14/1973' },
  { name: "chef anton's cajun seasoning", dongia: 22.00, giamgia: 0, ngay: '03/10/1976' },
  { name: "chef anton's gumbo mix", dongia: 21.35, giamgia: 3, ngay: '12/6/1978' },
  { name: "grandma's boysenberry spread", dongia: 25.00, giamgia: 3, ngay: '09/03/1981' },
  { name: "uncle bob's organic dried pears", dongia: 30.00, giamgia: 3, ngay: '03/13/1983' }
],
    pageSize: 8,
    currentPage: 1,
    sortDirection: 'asc',  
    sortProc: 'name',
    products: [
        { id: 1, name: "Đồng hồ thụy sỹ", image: require("@/assets/images/1001.jpg"), price: 1200, incart: 1, total: 0 },
        { id: 2, name: "Dell Star X", image: require("@/assets/images/1003.jpg"), price: 700, incart: 1, total: 0 },
        { id: 3, name: "Sony Vaio 2017", image: require("@/assets/images/1004.jpg"), price: 1700, incart: 1, total: 0 },
        { id: 4, name: "Máy ảnh Canon", image: require("@/assets/images/1005.jpg"), price: 300, incart: 1, total: 0 },
        { id: 5, name: "Vòng cưới France", image: require("@/assets/images/1009.jpg"), price: 7000, incart: 1, total: 0 },
        { id: 6, name: "Motorola thế hệ 5", image: require("@/assets/images/1011.jpg"), price: 900, incart: 1, total: 0 },
        { id: 7, name: "Mũ cao bồi Mexico", image: require("@/assets/images/1014.jpg"), price: 100, incart: 1, total: 0 },
        { id: 8, name: "Nước hoa Korea", image: require("@/assets/images/1023.jpg"), price: 600, incart: 1, total: 0 },
      ],
      cart: [],
      searching: "",
      tongtien: 0,
   }
  },
  computed: {
    paginatedSanPham() {
      const sortedData = this.sortedProducts();
      const startIndex = (this.currentPage - 1) * this.pageSize;
      const endIndex = startIndex + this.pageSize;
      return sortedData.slice(startIndex, endIndex);
    },
    pageCount() {
      return Math.ceil(this.sanpham.length / this.pageSize);
    },
    itemcount() {
      return this.cart.reduce((sum, item) => sum + item.incart, 0);
    },
    sumTotal() {
      return this.cart.reduce((sum, item) => sum + item.incart * item.price, 0);
    },
  },
  methods: {
    formatDate(dateString) {
    if (dateString) {
      const date = new Date(dateString);
      const day = date.getDate().toString().padStart(2, '0');
      const month = (date.getMonth() + 1).toString().padStart(2, '0');
      const year = date.getFullYear();
      return `${day}-${month}-${year}`;
    }
    return '';
  },
        kiemtra() {
          var sm = document.querySelectorAll("small");
          var tensp = document.getElementById("tensp");
        if (tensp.value.length == 0) {
            sm[0].style.display = "block";
            sm[0].innerText = "* Vui lòng nhập họ và tên"
        }
        else if (!isNaN(tensp.value)) {
            sm[0].style.display = "block";
            sm[0].innerText = "* Vui lòng nhập chữ"
        }
        else if (tensp.value.length >25) {
            sm[0].style.display = "block";
            sm[0].innerText = "* Vui lòng nhập họ và tên bé hơn 25 ký tự"
        }
        else if (tensp.value.length >=1|| tensp.value.length <=25) {
            sm[0].style.display = "none";
        }
        var diem = document.getElementById("diem");
        if (diem.value.length == 0) {
            sm[1].style.display = "block";
            sm[1].innerText = "* Vui lòng nhập điểm"
        }
        else if (diem.value<0 || diem.value>10) {
            sm[1].style.display = "block";
            sm[1].innerText = "* Vui lòng nhập điểm từ 0 đến 10"
        }
        else if (diem.value>=0 || diem.value<=10) {
            sm[1].style.display = "none";
        }
        var email = document.getElementById("email");
        if (email.value.length == 0) {
            sm[2].style.display = "block";
            sm[2].innerText = "* Vui lòng nhập email"
        }
        else if (email.value.indexOf("@") < 1) {
            sm[2].style.display = "block";
            sm[2].innerText = "* Vui lòng nhập email có dấu @"
        }
        else if (email.value.indexOf(".com") < 1) {
            sm[2].style.display = "block";
            sm[2].innerText = "* Vui lòng nhập email có chữ .com"
        }
        else if (email.value.length > 0 ) {
            sm[2].style.display = "none";
        }
        var soxe = document.getElementById("soxe");
        var bonkytu = soxe.value.slice(-5);
        var gach = soxe.value.split("-");
        var phanTuCuoiCung = gach[gach.length - 1];
        var giua = gach.length > 1 ? gach[1] : "";
        var ktgiua = /^[A-Z]\d$|^[A-Z]{2}$/;

        if (soxe.value.length == 0) {
          sm[3].style.display = "block";
          sm[3].innerText = "* Vui lòng nhập số xe";
        } else if (soxe.value.indexOf("5") !== 0) {
          sm[3].style.display = "block";
          sm[3].innerText = "* Vui lòng nhập số xe bắt đầu từ 5";
        } else if (!ktgiua.test(giua)) {
          sm[3].style.display = "block";
          sm[3].innerText = "* Phần giữa của số xe không hợp lệ";
        } else if (phanTuCuoiCung.length < 4 || phanTuCuoiCung.length > 5) {
          sm[3].style.display = "block";
          sm[3].innerText = "* Ký tự cuối phải là 4 hoặc 5 số";
        } else if (isNaN(bonkytu) || bonkytu.length !== 4 && bonkytu.length !== 5) {
          sm[3].style.display = "block";
          sm[3].innerText = "* 4 hoặc 5 ký tự cuối của số xe phải là số";
        } else {
          sm[3].style.display = "none";
        }
        },
        formatCurrency(value) {
      const formattedValue = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);
      return formattedValue;
    },
    capitalizeProductName(product) {
    return product.name.toUpperCase();
  },
  prevPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  },
  nextPage() {
    if (this.currentPage < this.pageCount) {
      this.currentPage++;
    }
  },
    sortedProducts() {
      return this.sanpham.sort((a, b) => {
        const modifier = this.sortDirection === 'desc' ? -1 : 1;
        return a[this.sortProc] > b[this.sortProc] ? modifier : -modifier;
      });
    },
    sortBy(key) {
  
      this.sortProc = key;
    this.currentPage = 1;
    return this.sortProc;
  },
  sortByAscending() {
    this.sortDirection = 'asc';
    this.currentPage = 1;
  },
  sortByDescending() {
    this.sortDirection = 'desc';
    this.currentPage = 1;
  },
  
  addCart(item) {
  console.log('Adding to cart:', item);
  var flag = false;

  if (this.cart.length === 0) {
    flag = false;
  } else {
    for (var i = 0; i < this.cart.length; i++) {
      if (this.cart[i].id === item.id) {
        flag = true;
      }
    }
  }

  if (flag === false) {
    this.cart.push({ item, incart: 1 });
  } else {
    for (var j = 0; j < this.cart.length; j++) {
      if (this.cart[j].id === item.id) {
        this.cart[j].incart++;
      }
    }
  }

  console.log('Updated cart:', this.cart);
},


    filterName() {
      if (this.searching == null) {
        return this.products;
      } else {
        if (this.searching) {
          return this.products.filter((item) => {
            return this.searching
              .toUpperCase()
              .split(" ")
              .every((v) => item.name.toUpperCase().includes(v));
          });
        } else {
          return this.products;
        }
      }
    },
    
    increment(item) {
      item.incart++;
      return item.incart;
    },
    Delete(index) {
      // Sử dụng Vue.delete để xóa phần tử từ mảng
      this.$delete(this.cart, index);
    },
    decrement(item) {
      item.incart--;
      return item.incart;
    },
    DeleteAll() {
      this.cart = [];
    },
    showCartModal() {
    console.log('Show cart modal');
  },
    
    },
    
}
</script>
<style>
small {
  color: red;
}
th,td {
  padding: 10px;

}
th {
  color: darkseagreen;
}
img{
    width: 100%;
    height: 100%;
}
.input[type=text] {
    width: 150px;
    -webkit-transition: width 1sease-in-out;
    transition: width 1sease-in-out;
}
.input[type=text]:focus{
    width: 80%;
}
</style>